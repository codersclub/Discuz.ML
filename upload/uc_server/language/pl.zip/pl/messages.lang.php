<?php
//------------------------------------------------------
// INTERNATIONAL UCenter v.1.6.0 (Multilingual)
// by Valery Votintsev, codersclub.org
//------------------------------------------------------
// Based on UCenter 1.6.0, (c) Comsenz.inc, discuz.net
//------------------------------------------------------
// Polish Language Pack
// by kaaleth, codersclub.org
//------------------------------------------------------

$lang = array(
	'please_login'			=> 'Prosz� zalogowa� si� ponownie.',
	'receiver_no_exists'		=> 'Podany odbiorca nie istnieje.',
	'pm_save_succeed'		=> 'Wiadomo�� zosta�a zapisana jako szkic.',
	'pm_send_succeed'		=> 'Wiadomo�� do $sent zosta�a wys�ana poprawnie.',
	'pm_send_announce_succeed'	=> 'Wiadomo�� zosta�a wys�ana poprawnie.',
	'pm_send_ignore'		=> 'Wyst�pi� b��d podczas wysy�ania wiadomo�ci. Operacja przerwana.',
	'pm_delete_succeed'		=> 'Wiadomo�� zosta�a usuni�ta.',
	'pm_delete_invalid'		=> 'Nie mo�na usun�� wiadomo�ci.',
	'pm_unread'			=> 'Wiadomo�� zosta�a oznaczona jako nieprzeczytana.',
	'blackls_updated'		=> 'Lista ignorowanych zosta�a zaktualizowana.',
	'pm_kickmember_succeed'		=> 'U�ytkownik zosta� usuni�ty z grupowej konwersacji.',
	'pm_appendmember_succeed'	=> 'Nowy u�ytkownik do��czy� do grupowej konwersacji',
	'pm_appendmember_invalid'	=> 'Wyst�pi� b��d podczas dodawania nowego u�ytkownika.',
	'pm_send_chatpmmemberlimit_error'	=> 'Przekroczono limit odbiorc�w',
	'pm_send_pmfloodctrl_error'		=> 'Wysy�asz zbyt szybko kr�tkie wiadomo�ci! Prosz� odczeka� chwil�.',
	'pm_send_privatepmthreadlimit_error'	=> 'You have exceeded the maximum number of messages per 24 hours',
	'pm_send_chatpmthreadlimit_error'	=> 'You have exceeded the maximum number of group chat messages per 24 hours',
	'pm_clear_processing'			=> 'Processing messages from current to next ',
	'pm_clear_succeed'			=> 'Operacja zosta�a zako�czona.',
	'pm_delete_noselect'			=> 'Please select messages for processing',

	'db_export_filename_invalid'	=> 'Prosz� wprowadzi� nazw� kopii zapasowej pliku. Nie u�ywaj znak�w specjalnych.',
	'db_export_file_invalid'	=> 'Data file can not be saved to the host, please check the folder permissions.',
	'db_export_multivol_redirect'	=> 'Krok: Dane pliku #$volume zosta�y utworzone, program kontynuuje operacj�.',
	'db_export_multivol_succeed'	=> 'Gratulacj�, kopia zapasowa zosta�a utworzona. Zapis zosta� uko�czony.',
	'db_import_multivol_succeed'	=> 'Wszystkie dane zosta�y przywr�cone poprawnie.',
	'db_import_file_illegal'	=> 'Plik danych nie istnieje. Host nie zezwala na wysy�anie plik�w lub plik kt�ry chcesz wys�a� ma za du�y rozmiar.',
	'db_import_multivol_redirect'	=> 'Plik danych #$volume zosta� za�adowany, program kontynuuje operacj�.',
	'db_back_api_url_invalid'	=> 'Unable to connect this application backup port, please copy the file under Ucenter ROOT "api/dbbak.php" to this application "API" folder',
	'delete_dumpfile_success'	=> 'Kopia zapasowa zosta�a usuni�ta.',
	'delete_dumpfile_redirect'	=> 'Pliki kopii zapasowej aplikacji $appname zosta�y usuni�te, program usunie pozosta�o�ci po danych aplikacji.',
	'dbback_error_code_1'		=> 'Nie mo�na utworzy� nowego katalogu.',
	'dbback_error_code_2'		=> 'Wyst�pi� b��d podczas zapisu kopii zapasowej',
	'dbback_error_code_3'		=> 'B��d SQL',
	'dbback_error_code_4'		=> 'Katalog jest pusty lub nie istnieje',
	'dbback_error_code_5'		=> 'Kopia zapasowa nie istnieje',
	'dbback_error_code_6'		=> 'Backup files is missing',
	'dbback_error_code_7'		=> 'Katalog nie istnieje',
	'dbback_error_code_8'		=> 'Wyst�pi� b��d podczas usuwania kopii zapasowej',
	'dbback_error_code_9'		=> 'B��dny typ rozszerzenia bazy danych',
	'undefine_error'		=> 'Nieznany b��d',

	'app_add_url_invalid'		=> 'Wprowadzono b��dny adres URL',
	'app_add_ip_invalid'		=> 'Wprowadzono b��dny adres IP',
	'app_add_name_invalid'		=> 'Application name is invalid or duplicates with other applications. Please return to change',
	'read_plugin_invalid'		=> 'Read Plugin Failed',

	'syncappcredits_updated'	=> 'Application Money Policy Synchronized Successfully',

	'note_succeed'			=> 'Pomy�lne',
	'note_false'			=> 'B��d',
	'no_permission_for_this_module'	=> 'Nie masz odpowiednich zezwole�, aby m�c edytowa� ten modu�',
	'admin_user_exists'		=> 'Nazwa u�ytkownika ju� istnieje.',

	'mail_succeed'			=> 'Email zosta� wys�any',
	'mail_false'			=> 'Email nie zosta� wys�any',
	
	'user_edit_noperm'		=> 'Nie masz wystarczaj�cych uprawnie� na edycj� u�ytkownika.',

	'appid_invalid'			=> 'B��dny identyfikator aplikacji.',
	'app_apifile_not_exists'	=> 'Plik "#$apifile" nie istnieje, prosz� sprawdzi� �cie�k� aplikacji.',
	'app_apifile_too_low'		=> 'The API file "#$apifile" version is too low',
	'app_path_not_exists'		=> 'Wprowadzona �cie�ka nie istnieje.',
	'pm_send_seccode_error'		=> 'B��dny kod bezpiecze�stwa',
	'pm_send_regdays_error'		=> 'You can not send message within #$pmsendregdays day(s) after the registration',
	'pm_send_limit1day_error'	=> 'Przepraszamy, dzienny limit wiadomo�ci zosta� ju� wyczerpany.',
	'pm_send_floodctrl_error'	=> 'Przepraszamy, pr�bujesz zbyt szybko wysy�a� wiadomo�ci, prosz� chwil� odczeka�.',
	
	'file_check_failed'		=> 'Pliki nie istniej�! Nie mo�na doko�a� operacji.',
);