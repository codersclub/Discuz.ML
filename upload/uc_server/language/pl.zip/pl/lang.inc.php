<?php
//------------------------------------------------------
// INTERNATIONAL UCenter v.1.6.0 (Multilingual)
// by Valery Votintsev, codersclub.org
//------------------------------------------------------
// Based on UCenter 1.6.0, (c) Comsenz.inc, discuz.net
//------------------------------------------------------
// Polish Language Pack
// by kaaleth, codersclub.org
//------------------------------------------------------

define('UC_VERNAME', 'International Version');

$lang = array(

	'SC_GBK'		=> 'Simplified Chinese GBK',
	'TC_BIG5'		=> 'Traditional Chinese BIG5',
	'SC_UTF8'		=> 'Simplified Chinese  UTF8',
	'TC_UTF8'		=> 'Traditional Chinese UTF8',
	'PL_ISO'		=> 'POLISH ISO8859',
	'PL_UTF8'		=> 'POLISH UTF-8',

	'title_install'		=> SOFT_NAME.' proces instalacyjny',
	'agreement_yes'		=> 'Zgadzam si�',
	'agreement_no'		=> 'Nie zgadzam si�',
	'notset'		=> 'Bez limit�w',

	'message_title'		=> 'Wskaz�wka',
	'error_message'		=> 'B��d',
	'message_return'	=> 'Powr�t',
	'return'		=> 'Powr�t',
	'install_wizard'	=> 'Proces instalacyjny',
	'config_nonexistence'	=> 'Plik konfiguracyjny nie istnieje',
	'nodir'			=> 'Folder nie istnieje',
	'short_open_tag_invalid'	=> 'Prosz� w��czy� funkcj� "short_open_tag" w pliku php.ini.',
	'redirect'			=> 'Proces instalacyjny uruchomi si� automatycznie.<br>Je�li tak si� nie sta�o, kliknij tutaj.',

	'database_errno_2003'	=> 'B��d po��czenia z baz� danych, prosz� upewni� si�, czy baza danych zosta�a skonfigurowana poprawnie.',
	'database_errno_1044'	=> 'Wyst�pi� b��d podczas tworzenia nowej bazy danych, prosz� sprawdzi� jej nazw�.',
	'database_errno_1045'	=> 'B��d po��czenia z baz� danych, prosz� sprawdzi� nazw� u�ytkownika oraz has�o.',
	'database_errno_1064'	=> 'B��D SQL',

	'dbpriv_createtable'	=> 'Brak zezwole� "CREATE TABLE"',
	'dbpriv_insert'		=> 'Brak zezwole� "INSERT"',
	'dbpriv_select'		=> 'Brak zezwole� "SELECT"',
	'dbpriv_update'		=> 'Brak zezwole� "UPDATE"',
	'dbpriv_delete'		=> 'Brak zezwole� "DELETE"',
	'dbpriv_droptable'	=> 'Brak zezwole� "DROP TABLE"',

	'db_not_null'		=> 'Wygl�da na to, �e UCenter zosta� zainstalowany ju� wcze�niej. Kontynuacja instalacji wyczy�ci stare dane.',
	'db_drop_table_confirm'	=> 'Zainstalowa� i usun�� stare dane?',

	'writeable'		=> 'Mo�liwy zapis',
	'unwriteable'		=> 'Niemo�liwy zapis',
	'old_step'		=> 'Nast�pny krok',
	'new_step'		=> 'Poprzedni krok',

	'database_errno_2003'	=> 'Nie mo�na po��czy� si� z baz� danych. Upewnij si�, czy jest baza danych zosta�a ju� utworzona z poprawn� konfiguracj�.',
	'database_errno_1044'	=> 'Nie mo�na po��czy� si� z baz� danych, prosz� sprawdzi� nazw� bazy.',
	'database_errno_1045'	=> 'Nie mo�na po��czy� si� z baz� danych, prosz� sprawdzi� nazw� u�ytkownika oraz has�o.',

	'step_env_check_title'	=> 'Rozpocznij instalacj�',
	'step_env_check_desc'	=> 'Sprawdzanie �rodowiska oraz uprawnie�.',
	'step_db_init_title'	=> 'Instalacja danych',
	'step_db_init_desc'	=> 'Instalacja danych...',
	
	'step1_file'		=> 'Nazwa pliku',
	'step1_need_status'	=> 'Wymagane',
	'step1_status'		=> 'Aktualne',
	'not_continue'		=> 'Prosz� rozwi�za� problemy oznaczone czerwon� czcionk� i spr�bowa� ponownie.',

	'tips_dbinfo'			=> 'Informacje wej�ciowe',
	'tips_dbinfo_comment'		=> '',
	'tips_admininfo'		=> 'Informacje dotycz�ce konta Administratora',
	'tips_admininfo_comment'	=> 'Prosz� zapami�ta� has�o za�o�yciela, gdy� mo�e by� potrzebne do logowania si� w UCenter.',
	'step_ext_info_title'		=> 'Instalacja przebieg�a poprawnie.',
	'step_ext_info_desc'		=> 'Kliknij tutaj aby zalogowa� si�.',

	'ext_info_succ'			=> 'Instalacja zosta�a zako�czona',
	'install_locked'		=> 'Installation is Locked due to previous installation, if you want to install again, please delete <br /> '.str_replace(ROOT_PATH, '', $lockfile),
	'error_quit_msg'		=> 'Prosz� rozwi�za� nast�puj�ce b��dy.',

	'step_app_reg_title'		=> 'Konfiguracja �rodowiska',
	'step_app_reg_desc'		=> 'Check Server and Set UCenter',
	'tips_ucenter'			=> 'Please fill in related info of UCenter',
	'tips_ucenter_comment'		=> 'UCenter to g��wny rdze� oprogramowania Comsenz. Discuz! Instalacja forum wymaga tej�e aplikacji. Je�li UCenter zosta� zainstalowany wcze�niej, prosz� wype�ni� informacj� o jego dost�pie lub przej�� do <a href="http://www.discuz.com/" target="blank">centrum produkt�w Comsenz</a> aby pobra� i zainstalowa� to oprogramowanie.',

	'advice_mysql_connect'		=> 'Prosz� si� upewni�, czy modu� MySQL zosta� za�adowany poprawnie.',
	'advice_fsockopen'		=> 'Prosz� w��czy� funkcj� "allow_url_fopen" w pliku "php.ini". Je�li nie masz o tym zielonego poj�cia, skontaktuj si� z dostawc� us�ugi.',
	'advice_gethostbyname'		=> '"gethostbyname" function is needed. Please contact space provider to make sure it is enabled',
	'advice_file_get_contents'	=> 'Prosz� w��czy� funkcj� "allow_url_fopen" w pliku "php.ini". Je�li nie masz o tym zielonego poj�cia, skontaktuj si� z dostawc� us�ugi.d',
	'advice_xml_parser_create'	=> 'Funkcja XML wymaga wsparcia w PHP. Je�li nie masz o tym zielonego poj�cia, skontaktuj si� z dostawc� us�ugi.',

	'ucurl'				=> 'Adres URL do UCenter',
	'ucpw'				=> 'Has�o za�o�yciela UCenter',

	'tips_siteinfo'			=> 'Uzupe�nij informacje na temat strony.',
	'sitename'			=> 'Nazwa strony',
	'siteurl'			=> 'Adres URL strony',

	'forceinstall'			=> 'Force Install',
	'dbinfo_forceinstall_invalid'	=> 'You may modify table prefix to prevent data loss if current database contains data with the same table prefix; force install will erase all the previous data!',

	'click_to_back'			=> 'Kliknij tutaj, aby powr�ci�',
	'adminemail'			=> 'System Emaili',
	'adminemail_comment'		=> 'S�u�y do wysy�ania raport�w o b��dach skrypt�w',
	'dbhost_comment'		=> 'Host, najcz�ciej: localhost',
	'tablepre_comment'		=> 'Prosz� zmie� prefiks, je�li jedna baza zawiera� b�dzie kilka for�w.',
	'forceinstall_check_label'	=> 'Chc� wymaza� poprzednie dane!!!',

	'uc_url_empty'			=> 'Adres URL UCenter jest pusty, prosz� wype�ni� to pole.',
	'uc_url_invalid'		=> 'Format URL nie jest poprawny.',
	'uc_url_unreachable'		=> 'Adres URL UCenter nie jest poprawny.',
	'uc_ip_invalid'			=> 'Cannot resolve domain, please fill in website IP</font>',
	'uc_admin_invalid'		=> 'Wprowadzono b��dne has�o za�o�yciela, spr�buj ponownie.',
	'uc_data_invalid'		=> 'Po��czenie nie powiod�o si�, sprawd� adres URL do UCenter',
	'ucenter_ucurl_invalid'		=> 'Adres URL do UCenter jest pusty lub niepoprawny',
	'ucenter_ucpw_invalid'		=> 'Has�o za�o�yciela UCenter jest puste lub niepoprawne',
	'siteinfo_siteurl_invalid'	=> 'Adres URL strony jest pusty lub niepoprawny',
	'siteinfo_sitename_invalid'	=> 'Nazwa strony jest pusta lub niepoprawna',
	'dbinfo_dbhost_invalid'		=> 'Nazwa hosta bazy danych jest pusta lub niepoprawna',
	'dbinfo_dbname_invalid'		=> 'Nazwa bazy danych jest pusta lub niepoprawna',
	'dbinfo_dbuser_invalid'		=> 'Nazwa u�ytkownika bazy danych jest pusta lub niepoprawna',
	'dbinfo_dbpw_invalid'		=> 'Has�o jest puste lub niepoprawne',
	'dbinfo_adminemail_invalid'	=> 'Adres Email jest pusty lub niepoprawny',
	'dbinfo_tablepre_invalid'	=> 'Wprowadzono b��dny prefiks, nie mo�e zaczyna� si� od cyfr lub format jest niepoprawny "."',
	'admininfo_username_invalid'	=> 'Nazwa Administratora jest pusta lub niepoprawna',
	'admininfo_email_invalid'	=> 'Adres Administratora Email jest pusty lub niepoprawny',
	'admininfo_ucfounderpw_invalid'	=> 'Has�o Administratora jest puste, prosz� uzupe�ni� to pole',
	'admininfo_ucfounderpw2_invalid'	=> 'Wprowadzone has�a nie pasuj� do siebie',

	'username'			=> 'Nazwa Administratora',
	'email'				=> 'Email Administratora',
	'password'			=> 'Has�o Administratora',
	'password_comment'		=> 'Has�o Administratora nie mo�e by� puste.',
	'password2'			=> 'Prosz� powt�rzy� has�o.',

	'admininfo_invalid'		=> 'Dane Administratora s� niekompletne. Prosz� uzupe�ni� pomini�te pola.',
	'dbname_invalid'		=> 'Nazwa bazy danych jest pusta. Prosz� uzupe�ni� to pole.',
	'admin_username_invalid'	=> 'Wprowadzono b��dn� nazw� u�ytkownika. Rozmiar nie mo�e przekroczy� 15 znak�w. Nie u�ywaj znak�w specjalnych.',
	'admin_password_invalid'	=> 'Wprowadzone has�a nie pasuj� do siebie.',
	'admin_email_invalid'		=> 'Wprowadzono b��dny adres Email. By� mo�e zosta� ju� u�yty lub zawiera niepoprawne znaki.',
	'admin_invalid'			=> 'Dane Administratora s� niekompletne. Wszystkie pola s� wymagane.',
	'admin_exist_password_error'	=> 'Username exists, if you want to set it as forum admin, please fill in correct password, or change another username',

	'tagtemplates_subject'	=> 'Temat',
	'tagtemplates_uid'	=> 'UID',
	'tagtemplates_username'	=> 'Autor',
	'tagtemplates_dateline'	=> 'Data',
	'tagtemplates_url'	=> 'URL',

	'uc_version_incorrect'	=> 'Twoja wersja UCenter jest ju� nieaktualna. Prosz� zaktualizowa� do najnowszej wersji. Wydane angielskie: http://www.distown.net/forum-12-1.html, wersja oficjalna: http://www.comsenz.com/ .',
	'config_unwriteable'	=> 'Nie mo�na nadpisa� pliku konfiguracyjnego. Prosz� ustali� prawa do zapisu (777) dla "config.inc.php".',

	'install_in_processed'	=> 'Instalacja...',
	'install_succeed'	=> 'Zainstalowano poprawnie, kliknij tutaj, aby przej�� do kolejnego kroku.',
	'license'		=> '<div class="license"><h1>Licencja</h1>

<p> Copyright (c) 2001-2010, Hong Sing Imagination (Beijing) Co., Ltd. Wszystkie prawa zastrze�one.</p>

<p> Dzi�ki za wyb�r produktu UCenter. Mamy nadziej�, �e nasz wysi�ek zapewni Pa�stwu szybkie, wydajne i efektywne zarz�dzanie witryn�.</p>

<p> Sing Imagination (Beijing) Technology Co., Ltd. dla deweloper�w produktu UCenter, and they shall have UCenter products copyright. Sing Imagination (Beijing) Technology Co., Ltd. strona internetowa http://www.comsenz.com, UCenter oficjalnie dost�pny jest pod adresem http://www.discuz.com, wspiarcie otrzymasz na oficjalnym forum http://www.discuz . net.</p>

<p> Prawa dotycz�ce UCenter zosta�y zarejestrowane w administracji praw autorskich, w Chi�skiej Republice Narodowej i obejmuj� zasi�g mi�dzynarodowy. U�ytkownicy: osoby lub organizacje, profit b�d� non-profil, musz� dok�adnie zapozna� si� z umow�, zgodzi� si� i przestrzega� wszystkich jej warunk�w od momentu rozpocz�cia pracy z oprogramowaniem UCenter.</p>

<p> Niniejsza licencja odno�i si� tylko i wy��cznie do aplikacji UCenter w wersji 1.x. Tylko Hong Sing Imagination (Beijing) Technology Co., Ltd. posiada mo�liwo�� jej interpretacji.</p>

<h3> I. license agreement right </h3>
<ol>
<li> you can fully comply with the end user license agreement, based on the software used in this non-commercial use, without having to pay for software copyright licensing fees.</li>
<li> agreement you can within the constraints and limitations UCenter modify the source code (if provided) or interface styles to suit your site requirements.</li>
<li> you have to use this software to build the site all the members of the information, articles and related information of ownership, and is independent of commitment and legal obligations related to the article content.</li>
<li> a commercial license, you can use this software for commercial applications, while according to the type of license purchased to determine the period of technical support, technical support, technical support form and content, from the moment of purchase, within the period of technical support have a way to get through the specified designated areas of technical support services. Business authorized users have the power to reflect and comment, relevant comments will be a primary consideration, but not necessarily be accepted promise or guarantee.</li>
</ol>

<h3> II. agreement constraints and limitations </h3>
<ol>
<li> business license has not been before, may not use this software for commercial purposes (including but not limited to business sites, business operations, for commercial purpose or profit web site). Purchase of commercial license, please visit http://www.discuz.com reference instructions, call 8610-51657885 for more details.</li>
<li> may not associated with the software or business license for rental, sale, mortgage or grant sub-licenses.</li>
<li> In any case, that no matter how used, whether modified or landscaping, changes to what extent, just use UCenter whole or any part, without the written permission of the page footer Department UCenter name and Sing Imagination (Beijing) Technology Co., Ltd. affiliated website (http://www.comsenz.com, http://www.discuz.com or http://www.discuz.net) the link must be retained, not removed or modified.</li>
<li> prohibited UCenter whole or any part of the basis for the development of any derivative version, modified version or third-party version for redistribution.</li>
<li> If you failed to comply with the terms of this Agreement, your authorization will be terminated by the license rights will be recovered, and bear the corresponding legal responsibility.</li>
</ol>

<h3> III. Limited Warranty and Disclaimer </h3>
<ol>
<li> the software and the accompanying documents as not to provide any express or implied, or guarantee in the form of compensation provided.</li>
<li> user voluntary use of this software, you must understand the risks of using this software, technical services in the not to buy products, we do not promise to provide any form of technical support, use the warrant or assume any use of this software issues related to liability arising.</li>
<li> Sing Imagination (Beijing) Technology Co., Ltd. does not use the software to build the site responsible for articles or information.</li>
</ol>

<p> the UCenter end user license agreement, business license and technical services to the details provided by UCenter exclusive official website. Sing Imagination (Beijing) Technology Co., Ltd. has, without prior notice, modify the license agreement and the power of service price list, the revised agreement or change list from the date of the new authorized user effect.</p>

<p> electronic text form of license agreement as the two sides signed an agreement in writing as a complete and equivalent legal effect. Once you start the installation UCenter, shall be deemed to fully understand and accept the terms of this Agreement, in the enjoyment of the powers conferred by these provisions, while subject to restrictions and limitations related. Acts outside the scope of protocol licensing will be a direct violation of the licensing agreement and constitutes infringement, we have the right to terminate the authorization, shall be ordered to stop the damage, and reserves the power to investigate ?? responsibility.</p></div>',

	'uc_installed'		=> 'UCenter zosta� ju� zainstalowany. Je�li chcesz przeinstalowa� program, prosz� usun�� plik "data/install.lock"',
	'i_agree'		=> 'Zgadzam si�',
	'supportted'		=> 'Wspierane',
	'unsupportted'		=> 'Nie wspierane',
	'max_size'		=> 'Wspiera/Maks. rozmiar',
	'project'		=> 'Projekt',
	'ucenter_required'	=> 'Wymagania UCenter',
	'ucenter_best'		=> 'UCenter rz�dzi!',
	'curr_server'		=> 'Aktualnie',
	'env_check'		=> 'Sprawd� �rodowisko',
	'os'			=> 'System operacyjny',
	'php'			=> 'Wersja PHP',
	'attachmentupload'	=> 'Upload za��cznik�w',
	'unlimit'		=> 'Bez limit�w',
	'version'		=> 'Wersja',
	'gdversion'		=> 'Wersja GD',
	'allow'			=> 'Zezwala',
	'unix'			=> 'Unix',
	'diskspace'		=> 'Przestrze� dysku',
	'priv_check'		=> 'Sprawd� katalog & Uprawnienia plik�w',
	'func_depend'		=> 'Check Depended Functions',
	'func_name'		=> 'Funkcja',
	'check_result'		=> 'Rezultat',
	'suggestion'		=> 'Sugestia',
	'advice_mysql'		=> 'Prosz� sprawdzi�, czy modu� MySQL zosta� za�adowany.',
	'advice_fopen'		=> 'Prosz� w��czy� funkcj� "allow_url_fopen" w pliku "php.ini". Je�li nie masz o tym zielonego poj�cia, skontaktuj si� z dostawc� us�ugi.',
	'advice_file_get_contents'	=> 'Prosz� w��czy� funkcj� "allow_url_fopen" w pliku "php.ini". Je�li nie masz o tym zielonego poj�cia, skontaktuj si� z dostawc� us�ugi.',
	'advice_xml'		=> 'Funkcja XML wymaga wsparcia w PHP. Je�li nie masz o tym zielonego poj�cia, skontaktuj si� z dostawc� us�ugi.',
	'none'			=> 'Brak',

	'dbhost'	=> 'Host BD',
	'dbuser'	=> 'U�ytkownik BD',
	'dbpw'		=> 'Has�o BD',
	'dbname'	=> 'Nazwa BD',
	'tablepre'	=> 'Prefiks tabel',

	'ucfounderpw'	=> 'Has�o za�o�yciela',
	'ucfounderpw2'	=> 'Potwierdzenie has�a',

	'create_table'	=> 'Tworzenie tabeli',
	'succeed'	=> 'Sukces!',
);