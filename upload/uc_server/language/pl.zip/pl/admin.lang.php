<?php
//------------------------------------------------------
// INTERNATIONAL UCenter v.1.6.0 (Multilingual)
// by Valery Votintsev, codersclub.org
//------------------------------------------------------
// Based on UCenter 1.6.0, (c) Comsenz.inc, discuz.net
//------------------------------------------------------
// Polish Language Pack
// by kaaleth, codersclub.org
//------------------------------------------------------
$lang = array(
	'user_search'		=> 'Wyszukaj u�ytkownika',
	'user_name'		=> 'U�ytkownik',
	'user_regdate'		=> 'Data rejestracji',
	'user_regip'		=> 'IP rejestracji',
	'user_before'		=> 'przed',
	'user_after'		=> 'po',
	'user_search'		=> 'Szukaj',
	'user_add'		=> 'Dodaj u�ytkownika',
	'user_password'		=> 'Has�o',
	'user_addsubmit'	=> 'Dodaj',
	'delete'		=> 'Usu�',
	'email'			=> 'Email',
	'user_list'		=> 'Lista u�ytkownik�w',
);