//------------------------------------------------------
// INTERNATIONAL UCenter v.1.6.0 (Multilingual)
// by Valery Votintsev, http://codersclub.org/
//------------------------------------------------------
// Based on UCenter 1.6.0, (c) Comsenz.inc, discuz.net
//------------------------------------------------------
// Polish Language Pack
// by kaaleth, codersclub.org
//------------------------------------------------------

//--------------------------------

var lng = {

//--------------------------------
//js/calendar.js
	'prev_month'	: 'Poprzedni miesi�c',//'???',
	'next_month'	: 'Nast�pny miesi�c',//'???',
	'select_year'	: 'Wybierz rok',//'??????',
	'select_month'	: 'Wybierz miesi�c',//'??????',
	'wday0'		: 'Ni',//'?',
	'wday1'		: 'Po',//'?',
	'wday2'		: 'Wt',//'?',
	'wday3'		: '�r',//'?',
	'wday4'		: 'Cz',//'?',
	'wday5'		: 'Pt',//'?',
	'wday6'		: 'So',//'?',
	'month'		: 'Miesi�c',//'?',
	'today'		: 'Dzie�',//'??',
	'hours'		: 'godz.',//'?',
	'minutes'	: 'min.',//'?',
	'ok'		: 'Ok',//'OK',
	'month_'	: '',//'?',// Dla daty, zb�dne dla j�zyka polskiego

//-------------------------------------
//	''	: '',//'',

'fiction'	: ''

};
